# Fleet and Logistics Management System

## Project Overview

A web-based fleet and logistics management system designed for small-to-medium logistics companies. Built as a cost-effective, multi-client solution that can be customized and white-labeled for different customers.

## Quick Links

- **[Requirements](./requirements.md)** - Functional requirements and user stories
- **[Design](./design.md)** - Technical architecture and implementation details  
- **[Decisions](./decisions.md)** - Architecture Decision Record (ADR) with detailed rationale

## Key Features

### Core Functionality
- ✅ Vehicle fleet management (add, edit, track trucks and small vehicles)
- ✅ Real-time GPS location tracking with history
- ✅ Cargo management (loading, unloading, status tracking)
- ✅ Driver management and assignment
- ✅ Dashboard with fleet overview and interactive map
- ✅ Search and filtering across vehicles and cargo
- ✅ Cargo operation audit trail

### Business Features
- ✅ Multi-tenant architecture (separate database per client)
- ✅ Tiered pricing (Basic/Standard/Premium) via feature flags
- ✅ White-label ready (configurable branding, colors, logo)
- ✅ Mobile-ready architecture for future driver app

## Technology Stack

| Layer | Technology | Why |
|-------|------------|-----|
| Backend | Python + FastAPI | Team expertise, auto API docs, built-in validation |
| Database | SQLite | Zero hosting cost, simple deployment |
| Frontend | React + TypeScript + Bootstrap 5 | Large community, easy white-labeling |
| Maps | Leaflet (abstracted) | Free, plug-and-play for future upgrades |
| Deployment | Docker Compose | Consistent environments, easy updates |

**See [decisions.md](./decisions.md) for detailed rationale behind each choice.**

## Business Model

### Pricing Tiers

| Feature | Basic ($200/mo) | Standard ($400/mo) | Premium ($800/mo) |
|---------|----------------|-------------------|-------------------|
| Max Vehicles | 10 | 50 | Unlimited |
| Max Cargo | 50 | 200 | Unlimited |
| Driver Management | ❌ | ✅ | ✅ |
| Advanced Reports | ❌ | ❌ | ✅ |
| Mobile App | ❌ | ❌ | ✅ |

### Cost Analysis

**Per-Client Hosting:**
- Our Stack: $6-11/month (SQLite + Docker + VPS)
- Alternative: $96-246/month (PostgreSQL + separate services + Google Maps)
- **Savings: $1,080-2,820/year per client** 💰

**Profit Margins:**
- Basic Tier: 95% margin ($190 profit on $200 price)
- Standard Tier: 97.5% margin ($390 profit on $400 price)
- Premium Tier: 92.5% margin ($740 profit on $800 price)

## Architecture Highlights

### Multi-Tenant Strategy
- **Separate SQLite database per client** for complete data isolation
- Easy backups (just copy the .db file)
- Clients can take their data anytime (builds trust)
- No tenant_id complexity in queries

### Feature Flags
- **Environment-based configuration** enables/disables features per tier
- Same codebase serves all pricing tiers
- Easy to upgrade/downgrade clients

### White-Label Customization
- **Configuration-driven branding** (colors, logo, company name)
- No code changes for new client
- Professional, customized appearance

### Plug-and-Play Maps
- **Abstract map interface** allows swapping providers
- Start with Leaflet (free)
- Upgrade to Google Maps/Mapbox for premium clients
- No map-specific code in business logic

## Development Phases

| Phase | Timeline | Focus |
|-------|----------|-------|
| **Phase 1** | Weeks 1-4 | Foundation (auth, database, basic UI) |
| **Phase 2** | Weeks 5-8 | Core features (vehicles, cargo, operations) |
| **Phase 3** | Weeks 9-12 | Dashboard, maps, location tracking |
| **Phase 4** | Weeks 13-16 | Polish (search, filtering, responsive design) |

## Getting Started (Future)

### For Developers
```bash
# Clone repository
git clone <repo-url>

# Backend setup
cd backend
python -m venv venv
source venv/bin/activate  # or `venv\Scripts\activate` on Windows
pip install -r requirements.txt

# Run migrations
alembic upgrade head

# Start backend
uvicorn app.main:app --reload

# Frontend setup (in new terminal)
cd frontend
npm install
npm run dev
```

### For Deployment
```bash
# Deploy with Docker
docker-compose up -d

# Update deployment
docker-compose pull && docker-compose up -d
```

## Configuration

### Per-Client .env File
```bash
# Client branding
CLIENT_NAME=ABC Logistics
CLIENT_LOGO=/assets/logos/abc-logo.png
PRIMARY_COLOR=#FF6600

# Tier and limits
TIER=standard
MAX_VEHICLES=50
FEATURE_DRIVER_MANAGEMENT=true

# Database
DB_FILE=data/abc_logistics.db

# Maps
MAP_PROVIDER=leaflet  # or google for premium
```

**See [decisions.md](./decisions.md) for complete configuration options.**

## Future Roadmap

### Phase 2 (After Launch)
- 📱 Mobile app for drivers (React Native - 80% code reuse)
- 📊 Advanced reporting and analytics
- 🗺️ Route optimization
- 🔔 Push notifications

### Phase 3 (Long-term)
- 🔴 Real-time tracking with WebSockets
- 🚧 Geofencing and alerts
- 🔧 Predictive maintenance
- 🤖 AI-powered insights

## Support and Documentation

### User Documentation (To Be Created)
- Getting started guide
- How-to guides for common tasks
- FAQ section
- Video tutorials

### Admin Documentation (To Be Created)
- Deployment guide
- Backup and restore procedures
- Troubleshooting guide
- Upgrade procedures

### API Documentation
- Auto-generated at `/docs` (FastAPI Swagger UI)
- Interactive testing interface
- Request/response schemas

## Success Metrics

### Business Goals
- 🎯 10 clients in first 6 months
- 📉 <10% annual churn rate
- 📈 60% basic, 30% standard, 10% premium tier mix

### Technical Goals
- ⚡ <200ms average API response time
- ✅ >99.5% uptime
- 📦 <500MB database per client
- 🚀 <2 second page load time

## Team Expertise

- ✅ **Strong:** Python backend development
- 🟡 **Learning:** React frontend development
- 🟢 **Adequate:** Database management, Docker deployment

## Questions or Issues?

Refer to detailed documentation in:
- [requirements.md](./requirements.md) - What the system should do
- [design.md](./design.md) - How the system is built
- [decisions.md](./decisions.md) - Why we made specific choices

---

**Project Status:** Requirements and Design Complete ✅  
**Next Step:** Generate task list and begin implementation  
**Last Updated:** July 9, 2026
