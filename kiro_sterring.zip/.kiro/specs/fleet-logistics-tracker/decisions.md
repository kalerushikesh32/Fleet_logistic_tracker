# Architecture Decision Record (ADR)

## Document Information

**Project:** Fleet and Logistics Management System  
**Date:** July 9, 2026  
**Status:** Active  
**Stakeholders:** Development Team, Business Owner

---

## Business Context

### Company Profile
- **Type:** Small company providing custom software solutions
- **Model:** Affordable, customized solutions for small-to-medium businesses
- **Target Clients:** Logistics companies with small fleets (typically <50 vehicles)
- **Support Model:** Single developer/small team provides ongoing support
- **Pricing Strategy:** Competitive, tiered pricing based on features

### Project Goals
1. Build reusable fleet management solution for multiple clients
2. Keep costs low for clients (hosting, licensing, maintenance)
3. Enable rapid customization per client
4. Support single-user initially, scale to multi-user later
5. Prepare for future mobile app for drivers
6. Easy to debug and maintain long-term

### Team Expertise
- **Backend:** Strong Python expertise
- **Frontend:** Zero experience (learning as we go)
- **Database:** Basic knowledge
- **DevOps:** Standard deployment experience

---

## Key Business Decisions

### BD-001: Multi-Client Architecture Strategy

**Decision:** Use separate SQLite database file per client

**Rationale:**
- Complete data isolation (security and privacy)
- Easy per-client backups (just copy the .db file)
- Clients can take their data anytime (builds trust)
- One client's issues don't affect others
- No complex tenant_id filtering in queries
- Simple to archive old clients

**Alternatives Considered:**
- Single database with tenant_id: Better for scaling but adds complexity
- PostgreSQL multi-schema: Overkill for small clients

**Implementation:**
```python
# Database path based on client
DATABASE_FILE = os.getenv("CLIENT_DB", "client_default.db")
db_url = f"sqlite:///{DATABASE_FILE}"
```

**Impact:**
- Deployment: Each client instance runs separate container with own DB
- Backup: Simple file copy per client
- Migration: Run migrations per client database

---

### BD-002: Pricing Tier Strategy

**Decision:** Implement feature flags via environment variables


**Rationale:**
- Same codebase serves all pricing tiers
- Easy to upgrade/downgrade clients
- No code changes for tier modifications
- Clear pricing differentiation

**Pricing Tiers:**

| Feature | Basic ($200/mo) | Standard ($400/mo) | Premium ($800/mo) |
|---------|----------------|-------------------|-------------------|
| Max Vehicles | 10 | 50 | Unlimited |
| Max Cargo | 50 | 200 | Unlimited |
| Vehicle Tracking | ✅ | ✅ | ✅ |
| Cargo Management | ✅ | ✅ | ✅ |
| Driver Management | ❌ | ✅ | ✅ |
| Advanced Reports | ❌ | ❌ | ✅ |
| Mobile App Access | ❌ | ❌ | ✅ |
| Priority Support | ❌ | ❌ | ✅ |

**Implementation:**
```bash
# .env file per tier
TIER=basic|standard|premium
MAX_VEHICLES=10
MAX_CARGO=50
FEATURE_DRIVER_MANAGEMENT=false
FEATURE_ADVANCED_REPORTS=false
FEATURE_MOBILE_APP=false
```

**Impact:**
- Sales: Clear upsell path for clients
- Development: Single codebase, minimal branching
- Support: Easy to identify client tier

---

### BD-003: White-Label Customization


**Decision:** Environment-based branding and theming

**Rationale:**
- No code changes for new client
- Professional, customized appearance
- Quick turnaround for deployments
- Easy to maintain per client

**Configuration:**
```bash
# Client branding
CLIENT_NAME="ABC Logistics"
CLIENT_LOGO_URL="/assets/logos/abc-logo.png"
PRIMARY_COLOR="#FF6600"
SECONDARY_COLOR="#333333"
ACCENT_COLOR="#00AAFF"

# Localization
TIMEZONE="Asia/Kolkata"
LANGUAGE="en"  # en, hi, mr, etc.
DATE_FORMAT="DD/MM/YYYY"
CURRENCY="INR"

# Contact
SUPPORT_EMAIL="support@yourcompany.com"
SUPPORT_PHONE="+91-XXXXXXXXXX"
```

**Impact:**
- Sales: Can demo with client's branding immediately
- Onboarding: Faster client setup
- Client satisfaction: Feels like "their" software

---

## Technical Decisions

### TD-001: Backend Technology Stack

**Decision:** Python + FastAPI

**Rationale:**

- Team has strong Python expertise (leverage existing skills)
- FastAPI auto-generates interactive API docs at `/docs` (huge debugging advantage)
- Built-in validation with Pydantic (fewer bugs, better error messages)
- Type hints make code self-documenting
- Async support for better performance
- Large Python ecosystem for any custom requirements

**Alternatives Considered:**
- Node.js + Express: Would require learning JavaScript on backend
- NestJS: More structured but steeper learning curve
- Go: Better performance but different language paradigm

**Trade-offs:**
- ✅ Use existing Python expertise
- ✅ Automatic API documentation
- ✅ Easy debugging with Python tools
- ❌ Slightly different from typical JavaScript full-stack (acceptable)

**Impact:**
- Development Speed: Faster (using known language)
- Debugging: Easier (familiar tools, auto docs)
- Maintenance: Simpler (one person can handle)

---

### TD-002: Database Choice

**Decision:** SQLite (with upgrade path to PostgreSQL)

**Rationale:**
- **Zero hosting costs** for clients (no separate DB server)
- **Simple deployment** (just a file, no DB admin needed)

- **Easy backups** (copy file)
- **Perfect for single-user** and small deployments
- **Lower client costs** (saves $20-50/month in DB hosting)
- **SQLAlchemy supports both** SQLite and PostgreSQL (easy migration path)

**Alternatives Considered:**
- PostgreSQL: Better for multi-user but requires separate server
- MongoDB: NoSQL flexibility not needed for structured logistics data
- MySQL: Similar to PostgreSQL but slightly less feature-rich

**When to Migrate to PostgreSQL:**
- Client needs multi-location/concurrent access (>10 users)
- Client requires advanced features (full-text search, JSON queries)
- Client specifically requests enterprise-grade DB

**Trade-offs:**
- ✅ Saves $240-600/year per client
- ✅ Simpler for clients to manage
- ✅ Easier deployment and backup
- ⚠️ Single-file write lock (not ideal for >20 concurrent users)
- ⚠️ Limited for distributed systems

**Implementation Notes:**
```python
# Database URL flexible for both
if os.getenv("DB_TYPE") == "postgresql":
    DATABASE_URL = os.getenv("POSTGRESQL_URL")
else:
    DATABASE_URL = f"sqlite:///{os.getenv('DB_FILE', 'fleet.db')}"
```

**Impact:**
- Client Costs: $5-10/month vs $30-80/month (huge savings)

- Deployment: Single container with everything
- Support: Fewer moving parts to debug

---

### TD-003: ORM Choice

**Decision:** SQLAlchemy 2.0 with Alembic for migrations

**Rationale:**
- Python ecosystem standard
- Works with both SQLite and PostgreSQL
- Type-safe queries
- Excellent documentation
- Migration system included (Alembic)
- Easy debugging (can print SQL with echo=True)

**Alternatives Considered:**
- Tortoise ORM: Async-first but smaller community
- Peewee: Simpler but less powerful
- Raw SQL: Too much manual work, no type safety

**Impact:**
- Database queries are type-safe and readable
- Easy to add new models/fields
- Migrations tracked in version control

---

### TD-004: Frontend Framework

**Decision:** React 18 + TypeScript

**Rationale:**
- **Largest community** = most StackOverflow answers (critical for beginner)
- **Component reusability** across clients

- **TypeScript catches bugs** before runtime (essential for non-frontend expert)
- **React Native** shares code for future mobile app (80% reuse)
- **Most AI/ChatGPT training** on React (better assistance)
- **Largest job market** (easier to hire help if needed)

**Alternatives Considered:**
- Vue 3: Simpler syntax but smaller ecosystem
- Svelte: Less boilerplate but much smaller community
- Vanilla JS: Too much manual work

**Trade-offs:**
- ⚠️ Steeper learning curve than Vue
- ✅ More resources to learn from
- ✅ Better for business (can hire React devs easily)
- ✅ Future mobile app easier

**Impact:**
- Learning: More documentation and tutorials available
- Mobile App: Can reuse components in React Native
- Hiring: Easier to find React developers if needed

---

### TD-005: UI Component Library

**Decision:** Bootstrap 5

**Rationale:**
- **Fast white-labeling** (change colors/logo easily)
- **Professional appearance** clients recognize
- **Less CSS knowledge required** (pre-built components)
- **Free and MIT licensed** (no costs ever)

- **Responsive by default** (works on desktop, tablet, phone)
- **Simple customization** via SCSS variables
- **Smaller learning curve** than utility-first CSS

**Alternatives Considered:**
- Tailwind CSS: More flexible but requires CSS understanding
- Material-UI: Modern but harder to customize per client
- Ant Design: Feature-rich but opinionated design

**Customization Strategy:**
```scss
// custom-theme.scss per client
$primary: #FF6600;
$secondary: #333333;
$font-family-base: 'Inter', sans-serif;

@import 'bootstrap';
```

**Trade-offs:**
- ✅ Faster client customization
- ✅ Less CSS knowledge required
- ✅ Professional, familiar look
- ⚠️ Less "modern" than Material-UI (acceptable for logistics)

**Impact:**
- Development: Faster UI implementation
- Customization: Easy theme per client
- Client Perception: Professional, trustworthy

---

### TD-006: State Management

**Decision:** TanStack Query (React Query) + React Context

**Rationale:**
- **TanStack Query handles all API complexity** (caching, loading, errors)
- **Less code to write** = faster development

- **Automatic refetching** when data goes stale
- **Built for API-heavy apps** like this
- **React Context for auth/config** (simple, built-in)

**Alternatives Considered:**
- Redux Toolkit: More boilerplate than needed
- Zustand: Good but doesn't handle API complexity
- Context only: Too manual for API calls

**Example Usage:**
```typescript
// Automatic loading, error, caching
const { data: vehicles, isLoading } = useQuery({
  queryKey: ['vehicles'],
  queryFn: fetchVehicles
});
```

**Impact:**
- Less code to maintain
- Better UX (automatic loading states)
- Easier debugging (React Query DevTools)

---

### TD-007: Maps Implementation

**Decision:** Leaflet with abstracted interface (plug-and-play)

**Rationale:**
- **Free and open-source** (no API costs)
- **No API key required** (simpler setup)
- **Lightweight** (good performance)
- **Abstracted interface** allows swapping providers later

**Alternatives Considered:**
- Google Maps: $200+/month at scale, requires API key
- Mapbox: Beautiful but paid after free tier


**Abstraction Pattern:**
```typescript
// Abstract interface
interface IMapProvider {
  displayMarker(id: string, lat: number, lon: number, label: string): void;
  updateMarker(id: string, lat: number, lon: number): void;
  removeMarker(id: string): void;
  setCenter(lat: number, lon: number, zoom: number): void;
}

// Implementations
class LeafletMapProvider implements IMapProvider { ... }
class GoogleMapProvider implements IMapProvider { ... }
class MapboxProvider implements IMapProvider { ... }

// Easy to swap
const mapProvider = config.mapType === 'google' 
  ? new GoogleMapProvider() 
  : new LeafletMapProvider();
```

**Trade-offs:**
- ✅ Zero map costs for all clients
- ✅ Can upgrade to Google Maps for premium clients
- ✅ Easy to test without API keys
- ⚠️ Basic tile quality (acceptable for tracking)

**Impact:**
- Client Costs: $0 vs $200+/month
- Flexibility: Can charge premium for Google Maps tier
- Development: No API key management

---

### TD-008: Authentication

**Decision:** JWT (JSON Web Tokens) + passlib for password hashing

**Rationale:**
- **Stateless** (scales well, no session storage)
- **Works across platforms** (web + future mobile)

- **Simple to implement** with FastAPI
- **Industry standard** (well-tested libraries)
- **passlib** provides secure bcrypt hashing

**Configuration:**
```python
# JWT settings
SECRET_KEY = os.getenv("JWT_SECRET_KEY")
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_HOURS = 24

# Password hashing
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
```

**Security Considerations:**
- Tokens expire after 24 hours
- Refresh token for extended sessions (future)
- Secret key per client deployment
- HTTPS in production (mandatory)

**Impact:**
- Security: Industry-standard approach
- Mobile Ready: Same tokens work in mobile app
- Simple: No session management needed

---

### TD-009: Deployment Strategy

**Decision:** Docker Compose with single container

**Rationale:**
- **Consistent environments** (dev = prod)
- **One-command deployment** for clients
- **Easy updates** (pull new image, restart)
- **Low resource usage** (SQLite + FastAPI + React SPA in one container)
- **Portable** (runs on any Docker host)

**Container Structure:**
```
fleet-tracker-container/
├── FastAPI backend (port 8000)
├── React static files (served by FastAPI)

└── SQLite database file (mounted volume)
```

**Deployment Options for Clients:**

| Hosting Option | Cost/Month | Complexity | Use Case |
|----------------|------------|------------|----------|
| DigitalOcean Droplet | $6 | Low | 1-3 clients per VPS |
| AWS Lightsail | $5 | Low | Cost-conscious clients |
| Client's own server | $0 | Medium | Enterprise clients |
| Your managed VPS | $2/client | Low | Multi-tenant hosting |

**Update Process:**
```bash
# Client runs to update
docker-compose pull
docker-compose up -d

# Zero downtime with rolling updates (future)
docker-compose up -d --no-deps --build backend
```

**Trade-offs:**
- ✅ Identical dev/prod environments
- ✅ Easy to support (same setup everywhere)
- ✅ Simple backup (just volume)
- ⚠️ Requires Docker knowledge (minimal)

**Impact:**
- Support: Easier debugging (consistent environments)
- Deployment: Faster onboarding of new clients
- Costs: Can host multiple clients on one VPS

---

## Architectural Decisions

### AD-001: Plug-and-Play Map Provider Architecture

**Decision:** Abstract map provider interface with swappable implementations


**Requirements:**
- Start with Leaflet (free)
- Easy to swap to Google Maps or Mapbox
- No map-specific code in business logic

**Implementation:**
```typescript
// src/services/maps/IMapProvider.ts
interface IMapProvider {
  initialize(containerId: string, center: [number, number], zoom: number): void;
  displayMarker(id: string, position: [number, number], options: MarkerOptions): void;
  updateMarker(id: string, position: [number, number]): void;
  removeMarker(id: string): void;
  setCenter(position: [number, number], zoom?: number): void;
  fitBounds(bounds: [[number, number], [number, number]]): void;
  destroy(): void;
}

// src/services/maps/MapFactory.ts
export function createMapProvider(type: MapType): IMapProvider {
  switch (type) {
    case 'leaflet': return new LeafletMapProvider();
    case 'google': return new GoogleMapProvider();
    case 'mapbox': return new MapboxMapProvider();
    default: return new LeafletMapProvider();
  }
}

// Usage in components
const mapProvider = createMapProvider(config.MAP_PROVIDER);
mapProvider.displayMarker('vehicle-1', [lat, lon], { label: 'Truck ABC' });
```

**Configuration:**
```bash
# .env
MAP_PROVIDER=leaflet  # or google, mapbox
GOOGLE_MAPS_API_KEY=  # only if using Google
MAPBOX_TOKEN=         # only if using Mapbox
```


**Benefits:**
- ✅ Easy to offer premium "Google Maps" tier
- ✅ No vendor lock-in
- ✅ Can test different providers easily
- ✅ Client-specific map providers

**Impact:**
- Premium Pricing: Charge extra for Google Maps
- Flexibility: Different providers for different clients
- Testing: Easy to mock in tests

---

### AD-002: Feature Flag System

**Decision:** Environment-based feature toggles for pricing tiers

**Implementation:**
```python
# backend/config.py
from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    # Tier configuration
    TIER: str = "basic"  # basic, standard, premium
    
    # Limits
    MAX_VEHICLES: int = 10
    MAX_CARGO: int = 50
    MAX_DRIVERS: int = 5
    
    # Features
    FEATURE_DRIVER_MANAGEMENT: bool = False
    FEATURE_ADVANCED_REPORTS: bool = False
    FEATURE_MOBILE_APP: bool = False
    FEATURE_REAL_TIME_TRACKING: bool = False
    FEATURE_ROUTE_OPTIMIZATION: bool = False
    
    class Config:
        env_file = ".env"

settings = Settings()

# Usage in endpoints
@app.post("/api/drivers")
async def create_driver(driver: DriverCreate):
    if not settings.FEATURE_DRIVER_MANAGEMENT:
        raise HTTPException(403, "Feature not available in your tier")
```


```typescript
// frontend/src/config/features.ts
export const features = {
  driverManagement: import.meta.env.VITE_FEATURE_DRIVER_MANAGEMENT === 'true',
  advancedReports: import.meta.env.VITE_FEATURE_ADVANCED_REPORTS === 'true',
  mobileApp: import.meta.env.VITE_FEATURE_MOBILE_APP === 'true',
};

// Usage in components
{features.driverManagement && <DriverManagementSection />}
```

**Benefits:**
- ✅ Single codebase for all tiers
- ✅ Easy upgrades (just change env vars)
- ✅ Clear feature differentiation
- ✅ Prevents feature creep for lower tiers

---

### AD-003: Database Migration Strategy

**Decision:** Alembic migrations with multi-client support

**Implementation:**
```bash
# Generate migration
alembic revision --autogenerate -m "add vehicle status field"

# Apply to all client databases
for client_db in client_*.db; do
    DATABASE_FILE=$client_db alembic upgrade head
done
```

**Rollback Strategy:**
```bash
# Backup before migration
cp client_abc.db client_abc.db.backup

# Migrate
alembic upgrade head

# Rollback if issues
alembic downgrade -1
# or restore backup
mv client_abc.db.backup client_abc.db
```

**Impact:**
- Safe schema changes across all clients
- Tracked in version control

- Easy to test migrations on staging first

---

## Cost Analysis

### Per-Client Hosting Cost Comparison

**Our Stack (SQLite + Docker + VPS):**
| Component | Cost |
|-----------|------|
| VPS (DigitalOcean/AWS) | $5-10/month |
| Database | $0 (SQLite) |
| Maps | $0 (Leaflet) |
| Domain + SSL | $1/month (Let's Encrypt) |
| **Total** | **$6-11/month** |

**Alternative Stack (PostgreSQL + Separate Services):**
| Component | Cost |
|-----------|------|
| Web Hosting (Vercel) | $20/month |
| PostgreSQL (Managed) | $25/month |
| Maps (Google) | $50-200/month |
| Domain + SSL | $1/month |
| **Total** | **$96-246/month** |

**Savings: $90-235/month per client = $1,080-2,820/year per client** 💰

### Client Pricing vs Cost

| Tier | Client Pays | Your Cost | Margin |
|------|-------------|-----------|--------|
| Basic | $200/month | $10/month | $190 (95%) |
| Standard | $400/month | $10/month | $390 (97.5%) |
| Premium | $800/month | $60/month* | $740 (92.5%) |

*Premium includes Google Maps ($50/month)

**Multi-Tenant Hosting (Your Infrastructure):**
- 1 VPS ($40/month) can host 10-15 clients
- Cost per client: $3-4/month
- Even higher margins!

---

## Future Considerations

### FC-001: Mobile App Development


**Planned Approach:** React Native

**Rationale:**
- Reuse React components (80% code sharing)
- Same developer skills
- Single API serves both web and mobile
- Cross-platform (iOS + Android)

**Timeline:** After web app is stable and 5+ clients onboarded

---

### FC-002: Real-Time Location Tracking

**Options for Future:**
1. **WebSockets** (FastAPI native support)
2. **Server-Sent Events** (simpler, one-way)
3. **Polling** (current approach, simplest)

**Decision:** Start with polling (every 30 seconds), add WebSockets in Premium tier

---

### FC-003: Advanced Features Roadmap

**Phase 1 (Current):** Core tracking and management  
**Phase 2 (3 months):** Mobile app for drivers  
**Phase 3 (6 months):** Route optimization, advanced reports  
**Phase 4 (9 months):** Real-time tracking, geofencing  
**Phase 5 (12 months):** Predictive maintenance, AI insights  

Each phase = new premium feature = upsell opportunity

---

## Implementation Guidelines

### IG-001: Code Organization

**Backend:**
```
backend/
├── app/
│   ├── api/
│   │   ├── routes/
│   │   │   ├── vehicles.py
│   │   │   ├── cargo.py
│   │   │   ├── drivers.py
│   │   │   └── operations.py
│   │   └── dependencies.py
│   ├── models/
│   │   ├── vehicle.py
│   │   ├── cargo.py
│   │   └── driver.py
│   ├── schemas/
│   │   ├── vehicle.py
│   │   └── cargo.py
│   ├── services/
│   │   └── vehicle_service.py
│   ├── core/
│   │   ├── config.py
│   │   └── security.py
│   └── main.py
├── alembic/
├── tests/
└── requirements.txt
```


**Frontend:**
```
frontend/
├── src/
│   ├── components/
│   │   ├── common/
│   │   ├── vehicles/
│   │   ├── cargo/
│   │   └── drivers/
│   ├── pages/
│   ├── services/
│   │   ├── api/
│   │   └── maps/
│   │       ├── IMapProvider.ts
│   │       ├── LeafletMapProvider.ts
│   │       └── MapFactory.ts
│   ├── hooks/
│   ├── contexts/
│   ├── config/
│   │   └── features.ts
│   ├── types/
│   └── App.tsx
└── public/
```

---

### IG-002: Environment Configuration Template

**Per-Client .env File:**
```bash
# ===========================================
# CLIENT CONFIGURATION
# ===========================================
CLIENT_ID=abc_logistics
CLIENT_NAME=ABC Logistics
CLIENT_LOGO=/assets/logos/abc-logo.png

# ===========================================
# TIER AND FEATURES
# ===========================================
TIER=standard
MAX_VEHICLES=50
MAX_CARGO=200
MAX_DRIVERS=20
FEATURE_DRIVER_MANAGEMENT=true
FEATURE_ADVANCED_REPORTS=false
FEATURE_MOBILE_APP=false

# ===========================================
# BRANDING
# ===========================================
PRIMARY_COLOR=#FF6600
SECONDARY_COLOR=#333333
ACCENT_COLOR=#00AAFF

# ===========================================
# LOCALIZATION
# ===========================================
TIMEZONE=Asia/Kolkata
LANGUAGE=en
DATE_FORMAT=DD/MM/YYYY
CURRENCY=INR

# ===========================================
# DATABASE
# ===========================================
DB_TYPE=sqlite
DB_FILE=data/abc_logistics.db

# ===========================================
# SECURITY
# ===========================================
JWT_SECRET_KEY=<generate-unique-per-client>
JWT_EXPIRE_HOURS=24

# ===========================================
# MAPS
# ===========================================
MAP_PROVIDER=leaflet
# GOOGLE_MAPS_API_KEY=  # Only for premium
# MAPBOX_TOKEN=  # Only for premium

# ===========================================
# SUPPORT
# ===========================================
SUPPORT_EMAIL=support@yourcompany.com
SUPPORT_PHONE=+91-XXXXXXXXXX
```

---

## Testing Strategy

### Unit Tests
- Python: pytest for backend services
- TypeScript: Vitest for frontend components

### Integration Tests
- API endpoint tests with TestClient (FastAPI)
- Database migrations testing

### End-to-End Tests
- Playwright for critical user flows (future)

### Manual Testing Checklist
- [ ] Vehicle CRUD operations
- [ ] Cargo loading/unloading
- [ ] Map display and markers
- [ ] Search and filtering
- [ ] Different screen sizes
- [ ] Different tiers (feature flags)

---

## Security Considerations

### SEC-001: Data Isolation
- Each client has separate database file
- No shared data between clients
- API validates JWT contains correct client_id

### SEC-002: Password Security
- Bcrypt hashing with cost factor 12
- Minimum password length: 8 characters
- Password strength validation on frontend

### SEC-003: API Security
- All endpoints require authentication (except login)
- Input validation with Pydantic
- SQL injection prevention (SQLAlchemy ORM)
- XSS prevention (React auto-escaping)

### SEC-004: HTTPS in Production
- Required for all client deployments
- Let's Encrypt for free SSL certificates
- Docker setup includes SSL termination

---

## Monitoring and Support

### MON-001: Logging Strategy
```python
# Structured logging
import logging

logger.info("Vehicle created", extra={
    "client_id": client_id,
    "vehicle_id": vehicle.id,
    "license_plate": vehicle.license_plate
})
```

### MON-002: Error Tracking
- Consider Sentry for production (optional)
- Log errors to file per client
- Email alerts for critical errors

### MON-003: Backup Strategy
```bash
# Daily backup script
#!/bin/bash
DATE=$(date +%Y%m%d)
cp data/client.db backups/client_$DATE.db
# Keep last 30 days
find backups/ -name "*.db" -mtime +30 -delete
```

---

## Documentation Requirements

### DOC-001: User Documentation
- [ ] Getting started guide
- [ ] How to add vehicles
- [ ] How to track cargo
- [ ] How to generate reports
- [ ] FAQ section

### DOC-002: Admin Documentation
- [ ] Deployment guide
- [ ] Backup and restore procedures
- [ ] Upgrade guide
- [ ] Troubleshooting common issues

### DOC-003: Developer Documentation
- [ ] API documentation (auto-generated by FastAPI)
- [ ] Database schema documentation
- [ ] Frontend component documentation
- [ ] Environment configuration guide

---

## Success Metrics

### Business Metrics
- **Target:** 10 clients in first 6 months
- **Churn rate:** <10% annually
- **Average tier:** 60% basic, 30% standard, 10% premium
- **Support tickets:** <5 per client per month

### Technical Metrics
- **API response time:** <200ms average
- **Uptime:** >99.5%
- **Database size:** <500MB per client
- **Page load time:** <2 seconds

---

## Summary of Key Decisions

| Decision Area | Choice | Primary Reason |
|---------------|--------|----------------|
| Backend | Python + FastAPI | Team expertise, auto docs |
| Database | SQLite | Cost savings, simplicity |
| Frontend | React + TypeScript | Largest community |
| UI Library | Bootstrap 5 | Easy white-labeling |
| Maps | Leaflet (plug-and-play) | Zero cost, flexible |
| Auth | JWT | Stateless, mobile-ready |
| Deployment | Docker | Consistency, ease |
| Architecture | Multi-tenant (separate DBs) | Data isolation |
| Pricing | Feature flag tiers | Single codebase |

---

## Approval

**Documented by:** Development Team  
**Date:** July 9, 2026  
**Status:** Approved for implementation  

**Next Steps:**
1. Update design.md with finalized stack
2. Generate task list for implementation
3. Set up development environment
4. Begin Phase 1 development
