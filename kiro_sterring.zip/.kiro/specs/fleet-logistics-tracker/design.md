# Technical Design Document

## Overview

This document outlines the technical architecture and design for the Fleet and Logistics Management System. The system is a web-based application for tracking fleet vehicles and cargo operations, built with a cost-optimized stack supporting multi-client deployment.

**Related Documents:**
- **[decisions.md](./decisions.md)** - Detailed Architecture Decision Record (ADR) with rationale for all technology and business decisions
- **[requirements.md](./requirements.md)** - Functional requirements and acceptance criteria

## Business Context

- **Company Model:** Small custom software solutions provider
- **Target Market:** Small-to-medium logistics companies with <50 vehicles
- **Pricing Strategy:** Tiered pricing (Basic/Standard/Premium) from same codebase
- **Architecture:** Multi-tenant with separate database per client
- **Cost Optimization:** $6-11/month hosting per client vs $96-246/month alternatives
- **Team:** Python backend expertise, learning frontend development

## Technology Stack

> **Note:** See [decisions.md](./decisions.md) for detailed rationale behind each technology choice.

| Layer | Technology | Rationale |
|-------|------------|-----------|
| **Backend** | **Python + FastAPI** | Team Python expertise, auto API docs, built-in validation, easy debugging |
| **Database** | **SQLite** | Zero hosting cost, simple deployment, easy backup, upgradeable to PostgreSQL |
| **ORM** | **SQLAlchemy 2.0 + Alembic** | Python standard, works with SQLite/PostgreSQL, excellent docs |
| **Frontend** | **React 18 + TypeScript** | Largest ecosystem, component reusability, mobile app code sharing |
| **UI Library** | **Bootstrap 5** | Fast white-labeling, professional look, easy customization, free |
| **State Management** | **TanStack Query + React Context** | Handles API complexity, automatic caching/loading, less code |
| **Routing** | **React Router v6** | Standard routing solution for React SPAs |
| **Maps** | **Leaflet (abstracted)** | Free, plug-and-play design for future Google Maps/Mapbox |
| **Authentication** | **JWT + passlib** | Stateless auth, mobile-ready, Python standard libraries |
| **Build Tool** | **Vite** | Fast development, optimized production builds |
| **Deployment** | **Docker Compose** | Consistent environments, one-command deploy, easy updates |

### Key Architecture Decisions

1. **Multi-Client Strategy:** Separate SQLite database per client for data isolation
2. **Feature Flags:** Environment-based tier system (Basic/Standard/Premium)
3. **White-Label Ready:** Configuration-driven branding (colors, logo, name)
4. **Cost-Optimized:** $6-11/month hosting per client vs $96-246/month alternatives
5. **Plug-and-Play Maps:** Abstract interface allows swapping Leaflet/Google Maps/Mapbox

## Architecture

### High-Level Architecture

```
┌─────────────────────────────────────────────────────────────────────┐
│                         CLIENT (Browser)                            │
├─────────────────────────────────────────────────────────────────────┤
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐              │
│  │   Dashboard  │  │   Vehicles   │  │    Cargo     │              │
│  │   Component  │  │   Module     │  │    Module    │              │
│  └──────────────┘  └──────────────┘  └──────────────┘              │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐              │
│  │   Drivers    │  │  Operations  │  │  Map (IMapProvider)        │
│  │   Module     │  │   History    │  │  Leaflet/Google/Mapbox     │
│  └──────────────┘  └──────────────┘  └──────────────┘              │
│                          │                                          │
│              ┌───────────┴───────────┐                             │
│              │  TanStack Query       │                             │
│              │  Auth Context         │                             │
│              │  Feature Flags        │                             │
│              └───────────────────────┘                             │
└─────────────────────────────────────────────────────────────────────┘
                              │ HTTP/REST + JWT
                              ▼
┌─────────────────────────────────────────────────────────────────────┐
│                       SERVER (Python/FastAPI)                       │
├─────────────────────────────────────────────────────────────────────┤
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐              │
│  │  Auth        │  │  Vehicle     │  │  Cargo       │              │
│  │  Routes      │  │  Routes      │  │  Routes      │              │
│  └──────────────┘  └──────────────┘  └──────────────┘              │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐              │
│  │  Driver      │  │  Operation   │  │  Dashboard   │              │
│  │  Routes      │  │  Routes      │  │  Routes      │              │
│  └──────────────┘  └──────────────┘  └──────────────┘              │
│                          │                                          │
│              ┌───────────┴───────────┐                             │
│              │  Middleware           │                             │
│              │  (JWT Auth, Feature   │                             │
│              │   Validation, Limits) │                             │
│              └───────────────────────┘                             │
└─────────────────────────────────────────────────────────────────────┘
                              │ SQLAlchemy ORM
                              ▼
┌─────────────────────────────────────────────────────────────────────┐
│                       DATABASE (SQLite)                             │
├─────────────────────────────────────────────────────────────────────┤
│  Users │ Vehicles │ Cargo │ Drivers │ Operations │ Locations       │
│                                                                     │
│  Per-Client: client_abc.db, client_xyz.db (isolated)               │
└─────────────────────────────────────────────────────────────────────┘
```

### Deployment Architecture

```
┌─────────────────────────────────────────────────────────────────────┐
│                    Docker Container (Per Client)                    │
├─────────────────────────────────────────────────────────────────────┤
│  ┌────────────────────────────────────────────────────────────┐    │
│  │  FastAPI Server (port 8000)                                │    │
│  │  - Serves API endpoints                                    │    │
│  │  - Serves React static files                               │    │
│  │  - Reads config from .env                                  │    │
│  └────────────────────────────────────────────────────────────┘    │
│                              │                                      │
│  ┌────────────────────────────────────────────────────────────┐    │
│  │  Volume Mount: /data                                       │    │
│  │  - client_abc.db (SQLite database)                         │    │
│  │  - logs/                                                   │    │
│  │  - backups/                                                │    │
│  └────────────────────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────────────────────┘
         │
         ▼ Hosted on
┌─────────────────────────┐
│  VPS (DigitalOcean/AWS) │
│  - Can host 10-15       │
│    clients per VPS      │
│  - $6-40/month          │
└─────────────────────────┘
```

## Data Models

### Entity Relationship Diagram

```
┌─────────────┐       ┌─────────────┐       ┌─────────────┐
│    User     │       │   Vehicle   │───────│   Driver    │
├─────────────┤       ├─────────────┤  1:1  ├─────────────┤
│ id          │       │ id          │       │ id          │
│ email       │       │ licensePlate│       │ name        │
│ password    │       │ type        │       │ phone       │
│ name        │       │ make        │       │ email       │
│ createdAt   │       │ model       │       │ licenseNo   │
│ updatedAt   │       │ year        │       │ vehicleId   │
└─────────────┘       │ status      │       │ status      │
                      │ driverId    │       │ createdAt   │
                      │ createdAt   │       │ updatedAt   │
                      │ updatedAt   │       └─────────────┘
                      └─────────────┘
                            │ 1:N
                            ▼
                      ┌─────────────┐
                      │  Location   │
                      ├─────────────┤
                      │ id          │
                      │ vehicleId   │
                      │ latitude    │
                      │ longitude   │
                      │ timestamp   │
                      └─────────────┘

┌─────────────┐       ┌─────────────┐
│   Cargo     │───────│  Operation  │
├─────────────┤  1:N  ├─────────────┤
│ id          │       │ id          │
│ description │       │ cargoId     │
│ weight      │       │ vehicleId   │
│ length      │       │ type        │
│ width       │       │ latitude    │
│ height      │       │ longitude   │
│ origin      │       │ timestamp   │
│ destination │       │ notes       │
│ status      │       │ createdAt   │
│ vehicleId   │       └─────────────┘
│ createdAt   │
│ updatedAt   │
└─────────────┘
```

### Database Schema (SQLAlchemy)

```python
# backend/app/models/__init__.py
from sqlalchemy import Column, String, Integer, Float, DateTime, Enum, ForeignKey
from sqlalchemy.orm import relationship, declarative_base
from sqlalchemy.sql import func
import enum
import uuid

Base = declarative_base()

# Enums
class VehicleType(str, enum.Enum):
    TRUCK = "TRUCK"
    SMALL_VEHICLE = "SMALL_VEHICLE"

class VehicleStatus(str, enum.Enum):
    AVAILABLE = "AVAILABLE"
    IN_USE = "IN_USE"
    MAINTENANCE = "MAINTENANCE"
    INACTIVE = "INACTIVE"

class DriverStatus(str, enum.Enum):
    ACTIVE = "ACTIVE"
    INACTIVE = "INACTIVE"
    ON_LEAVE = "ON_LEAVE"

class CargoStatus(str, enum.Enum):
    PENDING = "PENDING"
    LOADED = "LOADED"
    IN_TRANSIT = "IN_TRANSIT"
    UNLOADED = "UNLOADED"
    DELIVERED = "DELIVERED"

class OperationType(str, enum.Enum):
    LOADING = "LOADING"
    UNLOADING = "UNLOADING"

# Models
class User(Base):
    __tablename__ = "users"
    
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    email = Column(String, unique=True, nullable=False, index=True)
    password = Column(String, nullable=False)
    name = Column(String, nullable=False)
    created_at = Column(DateTime, server_default=func.now())
    updated_at = Column(DateTime, onupdate=func.now())

class Vehicle(Base):
    __tablename__ = "vehicles"
    
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    license_plate = Column(String, unique=True, nullable=False, index=True)
    type = Column(Enum(VehicleType), nullable=False)
    make = Column(String, nullable=False)
    model = Column(String, nullable=False)
    year = Column(Integer, nullable=False)
    status = Column(Enum(VehicleStatus), default=VehicleStatus.AVAILABLE)
    created_at = Column(DateTime, server_default=func.now())
    updated_at = Column(DateTime, onupdate=func.now())
    
    # Relationships
    driver = relationship("Driver", back_populates="vehicle", uselist=False)
    locations = relationship("Location", back_populates="vehicle", cascade="all, delete-orphan")
    cargo = relationship("Cargo", back_populates="vehicle")
    operations = relationship("Operation", back_populates="vehicle")

class Driver(Base):
    __tablename__ = "drivers"
    
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    name = Column(String, nullable=False)
    phone = Column(String, nullable=False)
    email = Column(String, nullable=True)
    license_no = Column(String, unique=True, nullable=False, index=True)
    status = Column(Enum(DriverStatus), default=DriverStatus.ACTIVE)
    vehicle_id = Column(String, ForeignKey("vehicles.id"), unique=True, nullable=True)
    created_at = Column(DateTime, server_default=func.now())
    updated_at = Column(DateTime, onupdate=func.now())
    
    # Relationships
    vehicle = relationship("Vehicle", back_populates="driver")

class Location(Base):
    __tablename__ = "locations"
    
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    vehicle_id = Column(String, ForeignKey("vehicles.id"), nullable=False, index=True)
    latitude = Column(Float, nullable=False)
    longitude = Column(Float, nullable=False)
    timestamp = Column(DateTime, server_default=func.now(), index=True)
    
    # Relationships
    vehicle = relationship("Vehicle", back_populates="locations")

class Cargo(Base):
    __tablename__ = "cargo"
    
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    description = Column(String, nullable=False)
    weight = Column(Float, nullable=False)
    length = Column(Float, nullable=True)
    width = Column(Float, nullable=True)
    height = Column(Float, nullable=True)
    origin = Column(String, nullable=False)
    destination = Column(String, nullable=False)
    status = Column(Enum(CargoStatus), default=CargoStatus.PENDING, index=True)
    vehicle_id = Column(String, ForeignKey("vehicles.id"), nullable=True)
    created_at = Column(DateTime, server_default=func.now())
    updated_at = Column(DateTime, onupdate=func.now())
    
    # Relationships
    vehicle = relationship("Vehicle", back_populates="cargo")
    operations = relationship("Operation", back_populates="cargo", cascade="all, delete-orphan")

class Operation(Base):
    __tablename__ = "operations"
    
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    cargo_id = Column(String, ForeignKey("cargo.id"), nullable=False, index=True)
    vehicle_id = Column(String, ForeignKey("vehicles.id"), nullable=False, index=True)
    type = Column(Enum(OperationType), nullable=False)
    latitude = Column(Float, nullable=True)
    longitude = Column(Float, nullable=True)
    notes = Column(String, nullable=True)
    timestamp = Column(DateTime, server_default=func.now(), index=True)
    created_at = Column(DateTime, server_default=func.now())
    
    # Relationships
    cargo = relationship("Cargo", back_populates="operations")
    vehicle = relationship("Vehicle", back_populates="operations")
```

## API Design

### Authentication Endpoints

| Method | Endpoint | Description | Request Body | Response |
|--------|----------|-------------|--------------|----------|
| POST | `/api/auth/login` | User login | `{ email, password }` | `{ token, user }` |
| POST | `/api/auth/logout` | User logout | - | `{ success }` |
| GET | `/api/auth/me` | Get current user | - | `{ user }` |

### Vehicle Endpoints

| Method | Endpoint | Description | Request Body | Response |
|--------|----------|-------------|--------------|----------|
| GET | `/api/vehicles` | List all vehicles | Query: `?type=&status=&search=` | `{ vehicles[] }` |
| GET | `/api/vehicles/{id}` | Get vehicle details | - | `{ vehicle }` |
| POST | `/api/vehicles` | Create vehicle | `{ licensePlate, type, make, model, year }` | `{ vehicle }` |
| PUT | `/api/vehicles/{id}` | Update vehicle | `{ ...fields }` | `{ vehicle }` |
| PATCH | `/api/vehicles/{id}/status` | Update status | `{ status }` | `{ vehicle }` |
| DELETE | `/api/vehicles/{id}` | Deactivate vehicle | - | `{ success }` |
| GET | `/api/vehicles/{id}/locations` | Get location history | Query: `?from=&to=` | `{ locations[] }` |
| POST | `/api/vehicles/{id}/locations` | Add location | `{ latitude, longitude }` | `{ location }` |

### Cargo Endpoints

| Method | Endpoint | Description | Request Body | Response |
|--------|----------|-------------|--------------|----------|
| GET | `/api/cargo` | List all cargo | Query: `?status=&search=` | `{ cargo[] }` |
| GET | `/api/cargo/{id}` | Get cargo details | - | `{ cargo, operations[] }` |
| POST | `/api/cargo` | Create cargo | `{ description, weight, dimensions, origin, destination }` | `{ cargo }` |
| PUT | `/api/cargo/{id}` | Update cargo | `{ ...fields }` | `{ cargo }` |
| DELETE | `/api/cargo/{id}` | Delete cargo | - | `{ success }` |

### Operation Endpoints

| Method | Endpoint | Description | Request Body | Response |
|--------|----------|-------------|--------------|----------|
| GET | `/api/operations` | List operations | Query: `?from=&to=&vehicleId=&cargoId=` | `{ operations[] }` |
| POST | `/api/operations/load` | Load cargo | `{ cargoId, vehicleId, latitude?, longitude?, notes? }` | `{ operation, cargo, vehicle }` |
| POST | `/api/operations/unload` | Unload cargo | `{ cargoId, latitude?, longitude?, notes? }` | `{ operation, cargo, vehicle }` |

### Driver Endpoints

| Method | Endpoint | Description | Request Body | Response |
|--------|----------|-------------|--------------|----------|
| GET | `/api/drivers` | List all drivers | Query: `?status=&search=` | `{ drivers[] }` |
| GET | `/api/drivers/{id}` | Get driver details | - | `{ driver }` |
| POST | `/api/drivers` | Create driver | `{ name, phone, email?, licenseNo }` | `{ driver }` |
| PUT | `/api/drivers/{id}` | Update driver | `{ ...fields }` | `{ driver }` |
| POST | `/api/drivers/{id}/assign` | Assign to vehicle | `{ vehicleId }` | `{ driver, vehicle }` |
| POST | `/api/drivers/{id}/unassign` | Unassign from vehicle | - | `{ driver, vehicle }` |
| DELETE | `/api/drivers/{id}` | Deactivate driver | - | `{ success }` |

### Dashboard Endpoints

| Method | Endpoint | Description | Response |
|--------|----------|-------------|----------|
| GET | `/api/dashboard/summary` | Get dashboard stats | `{ vehicleStats, cargoStats }` |
| GET | `/api/dashboard/map` | Get map data | `{ vehicles[] with locations }` |
| GET | `/api/dashboard/recent-operations` | Recent operations | `{ operations[] }` |

## Frontend Component Structure

```
src/
├── components/
│   ├── common/
│   │   ├── Button.tsx
│   │   ├── Input.tsx
│   │   ├── Select.tsx
│   │   ├── Modal.tsx
│   │   ├── Table.tsx
│   │   ├── Card.tsx
│   │   ├── Badge.tsx
│   │   ├── SearchBar.tsx
│   │   ├── Pagination.tsx
│   │   └── LoadingSpinner.tsx
│   ├── layout/
│   │   ├── AppLayout.tsx
│   │   ├── Sidebar.tsx
│   │   ├── Header.tsx
│   │   └── PageContainer.tsx
│   ├── dashboard/
│   │   ├── Dashboard.tsx
│   │   ├── StatsCard.tsx
│   │   ├── FleetMap.tsx
│   │   └── RecentOperations.tsx
│   ├── vehicles/
│   │   ├── VehicleList.tsx
│   │   ├── VehicleCard.tsx
│   │   ├── VehicleForm.tsx
│   │   ├── VehicleDetails.tsx
│   │   ├── VehicleStatusBadge.tsx
│   │   └── LocationHistory.tsx
│   ├── cargo/
│   │   ├── CargoList.tsx
│   │   ├── CargoCard.tsx
│   │   ├── CargoForm.tsx
│   │   ├── CargoDetails.tsx
│   │   ├── CargoStatusBadge.tsx
│   │   ├── LoadCargoModal.tsx
│   │   └── UnloadCargoModal.tsx
│   ├── drivers/
│   │   ├── DriverList.tsx
│   │   ├── DriverCard.tsx
│   │   ├── DriverForm.tsx
│   │   ├── DriverDetails.tsx
│   │   └── AssignDriverModal.tsx
│   ├── operations/
│   │   ├── OperationList.tsx
│   │   ├── OperationCard.tsx
│   │   └── OperationFilters.tsx
│   └── auth/
│       ├── LoginForm.tsx
│       └── ProtectedRoute.tsx
├── contexts/
│   ├── AuthContext.tsx
│   └── AppContext.tsx
├── hooks/
│   ├── useAuth.ts
│   ├── useVehicles.ts
│   ├── useCargo.ts
│   ├── useDrivers.ts
│   ├── useOperations.ts
│   └── useDashboard.ts
├── services/
│   ├── api.ts
│   ├── authService.ts
│   ├── vehicleService.ts
│   ├── cargoService.ts
│   ├── driverService.ts
│   └── operationService.ts
├── types/
│   ├── vehicle.ts
│   ├── cargo.ts
│   ├── driver.ts
│   ├── operation.ts
│   └── user.ts
├── utils/
│   ├── validators.ts
│   ├── formatters.ts
│   └── constants.ts
├── pages/
│   ├── LoginPage.tsx
│   ├── DashboardPage.tsx
│   ├── VehiclesPage.tsx
│   ├── VehicleDetailPage.tsx
│   ├── CargoPage.tsx
│   ├── CargoDetailPage.tsx
│   ├── DriversPage.tsx
│   ├── DriverDetailPage.tsx
│   └── OperationsPage.tsx
├── App.tsx
└── main.tsx
```

## Backend Structure

```
backend/
├── app/
│   ├── api/
│   │   ├── routes/
│   │   │   ├── auth.py
│   │   │   ├── vehicles.py
│   │   │   ├── cargo.py
│   │   │   ├── drivers.py
│   │   │   ├── operations.py
│   │   │   └── dashboard.py
│   │   └── dependencies.py       # Shared deps (get_db, get_current_user)
│   ├── models/                   # SQLAlchemy ORM models
│   │   ├── __init__.py
│   │   ├── user.py
│   │   ├── vehicle.py
│   │   ├── driver.py
│   │   ├── location.py
│   │   ├── cargo.py
│   │   └── operation.py
│   ├── schemas/                  # Pydantic request/response schemas
│   │   ├── user.py
│   │   ├── vehicle.py
│   │   ├── cargo.py
│   │   ├── driver.py
│   │   └── operation.py
│   ├── services/                 # Business logic layer
│   │   ├── auth_service.py
│   │   ├── vehicle_service.py
│   │   ├── cargo_service.py
│   │   ├── driver_service.py
│   │   └── operation_service.py
│   ├── core/
│   │   ├── config.py             # Settings (pydantic-settings, feature flags)
│   │   ├── security.py           # JWT + password hashing
│   │   └── database.py           # SQLAlchemy engine/session setup
│   └── main.py                   # FastAPI app entry point
├── alembic/                      # Database migrations
│   ├── versions/
│   └── env.py
├── tests/
│   ├── test_vehicles.py
│   ├── test_cargo.py
│   └── conftest.py
├── data/                         # SQLite database files (per client)
├── .env                          # Client configuration
├── alembic.ini
└── requirements.txt
```

## Components and Interfaces

### Dashboard Component

```typescript
// src/components/dashboard/Dashboard.tsx

interface DashboardProps {}

interface VehicleStats {
  total: number;
  active: number;
  inUse: number;
  maintenance: number;
  inactive: number;
}

interface CargoStats {
  pending: number;
  loaded: number;
  inTransit: number;
  unloaded: number;
  delivered: number;
}

// Features:
// - Display stats cards for vehicles and cargo
// - Render interactive map with vehicle markers
// - Show recent operations list
// - Manual refresh button
// - Responsive grid layout
```

### Vehicle Form Component

```typescript
// src/components/vehicles/VehicleForm.tsx

interface VehicleFormProps {
  vehicle?: Vehicle;  // For edit mode
  onSubmit: (data: VehicleFormData) => Promise<void>;
  onCancel: () => void;
}

interface VehicleFormData {
  licensePlate: string;
  type: 'TRUCK' | 'SMALL_VEHICLE';
  make: string;
  model: string;
  year: number;
}

// Validation rules:
// - License plate: required, unique, alphanumeric format
// - Type: required, enum selection
// - Make: required, 2-50 characters
// - Model: required, 2-50 characters
// - Year: required, 1900 - current year + 1
```

### Cargo Operations Flow

```typescript
// Loading operation flow
async function loadCargo(cargoId: string, vehicleId: string, location?: Location) {
  // 1. Validate cargo status is PENDING
  // 2. Validate vehicle status is AVAILABLE or IN_USE
  // 3. Create operation record
  // 4. Update cargo: status = LOADED, vehicleId = vehicleId
  // 5. Update vehicle: status = IN_USE
  // 6. Return updated entities
}

// Unloading operation flow
async function unloadCargo(cargoId: string, location?: Location, markDelivered?: boolean) {
  // 1. Validate cargo status is LOADED or IN_TRANSIT
  // 2. Get vehicleId from cargo
  // 3. Create operation record
  // 4. Update cargo: status = UNLOADED or DELIVERED, vehicleId = null
  // 5. Check if vehicle has remaining cargo
  // 6. If no cargo, update vehicle: status = AVAILABLE
  // 7. Return updated entities
}
```

## Authentication Flow

```
┌─────────┐       ┌─────────┐       ┌─────────┐
│ Client  │       │ Server  │       │   DB    │
└────┬────┘       └────┬────┘       └────┬────┘
     │                 │                 │
     │  POST /login    │                 │
     │  {email, pass}  │                 │
     │────────────────>│                 │
     │                 │  Find user      │
     │                 │────────────────>│
     │                 │     User        │
     │                 │<────────────────│
     │                 │                 │
     │                 │  Verify password│
     │                 │  Generate JWT   │
     │                 │                 │
     │   {token, user} │                 │
     │<────────────────│                 │
     │                 │                 │
     │  Store token    │                 │
     │  (localStorage) │                 │
     │                 │                 │
     │  GET /vehicles  │                 │
     │  Auth: Bearer   │                 │
     │────────────────>│                 │
     │                 │  Verify JWT     │
     │                 │  Extract userId │
     │                 │                 │
     │                 │  Query vehicles │
     │                 │────────────────>│
     │                 │    Vehicles     │
     │                 │<────────────────│
     │   {vehicles}    │                 │
     │<────────────────│                 │
```

## Validation Rules

### Vehicle Validation

| Field | Rules |
|-------|-------|
| licensePlate | Required, unique, alphanumeric with optional hyphens, 2-15 chars |
| type | Required, enum: TRUCK, SMALL_VEHICLE |
| make | Required, 2-50 characters |
| model | Required, 2-50 characters |
| year | Required, integer, 1900 to current year + 1 |

### Cargo Validation

| Field | Rules |
|-------|-------|
| description | Required, 3-200 characters |
| weight | Required, positive number, max 100000 kg |
| length | Optional, positive number |
| width | Optional, positive number |
| height | Optional, positive number |
| origin | Required, 2-100 characters |
| destination | Required, 2-100 characters |

### Driver Validation

| Field | Rules |
|-------|-------|
| name | Required, 2-100 characters |
| phone | Required, valid phone format |
| email | Optional, valid email format |
| licenseNo | Required, unique, alphanumeric, 5-20 chars |

## Error Handling

### API Error Response Format

```typescript
interface ApiError {
  status: number;
  code: string;
  message: string;
  details?: Record<string, string[]>;  // Field-level validation errors
}

// Example validation error
{
  "status": 400,
  "code": "VALIDATION_ERROR",
  "message": "Invalid input data",
  "details": {
    "licensePlate": ["License plate is required", "Must be alphanumeric"],
    "year": ["Must be a valid year"]
  }
}

// Example business logic error
{
  "status": 409,
  "code": "CARGO_ALREADY_LOADED",
  "message": "This cargo is already loaded on a vehicle"
}
```

### HTTP Status Codes

| Code | Usage |
|------|-------|
| 200 | Successful GET, PUT, PATCH |
| 201 | Successful POST (resource created) |
| 204 | Successful DELETE |
| 400 | Validation error |
| 401 | Authentication required |
| 403 | Permission denied |
| 404 | Resource not found |
| 409 | Conflict (duplicate, invalid state) |
| 500 | Internal server error |

## Configuration and Multi-Tenancy

> **Note:** Business rationale for these decisions is in [decisions.md](./decisions.md) (BD-001, BD-002, BD-003, AD-001, AD-002).

> **Scope note (deferred):** Multi-tenancy, tier limits (MAX_VEHICLES/MAX_CARGO/MAX_DRIVERS), feature flags, and white-label theming are treated as **deployment-configuration concerns, out of the current functional scope**. They are NOT covered by requirements.md and are NOT part of the initial task list. The current build targets a single-user deployment. These capabilities will be addressed in a later update, at which point matching requirements will be added. The examples below are documented now only to guide forward-compatible design (e.g., reading settings from config rather than hardcoding).

### Configuration System

All client-specific behavior is driven by environment variables loaded via `pydantic-settings`. No code changes are needed to onboard or reconfigure a client.

```python
# backend/app/core/config.py
from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    # Client identity / branding
    CLIENT_ID: str = "default"
    CLIENT_NAME: str = "Fleet Tracker"
    PRIMARY_COLOR: str = "#0d6efd"

    # Tier limits
    TIER: str = "basic"
    MAX_VEHICLES: int = 10
    MAX_CARGO: int = 50
    MAX_DRIVERS: int = 5

    # Feature flags
    FEATURE_DRIVER_MANAGEMENT: bool = False
    FEATURE_ADVANCED_REPORTS: bool = False
    FEATURE_MOBILE_APP: bool = False

    # Database
    DB_TYPE: str = "sqlite"
    DB_FILE: str = "data/default.db"

    # Security
    JWT_SECRET_KEY: str
    JWT_EXPIRE_HOURS: int = 24

    # Maps
    MAP_PROVIDER: str = "leaflet"

    class Config:
        env_file = ".env"

settings = Settings()
```

### Multi-Tenant Database Resolution

Each client runs as an isolated deployment (own container + own SQLite file). The database URL is resolved at startup from config, so there is no cross-tenant query logic in the application.

```python
# backend/app/core/database.py
if settings.DB_TYPE == "postgresql":
    DATABASE_URL = os.getenv("POSTGRESQL_URL")
else:
    DATABASE_URL = f"sqlite:///{settings.DB_FILE}"
```

### Feature Flag Enforcement

Feature flags and tier limits are enforced in the backend (authoritative) and mirrored in the frontend (UX only).

```python
# Backend: reject gated features
@router.post("/api/drivers")
def create_driver(payload: DriverCreate, db: Session = Depends(get_db)):
    if not settings.FEATURE_DRIVER_MANAGEMENT:
        raise HTTPException(403, "Feature not available in your tier")
    if db.query(Driver).count() >= settings.MAX_DRIVERS:
        raise HTTPException(403, f"Driver limit ({settings.MAX_DRIVERS}) reached")
    ...
```

```typescript
// Frontend: hide gated UI (Vite exposes VITE_* env vars)
export const features = {
  driverManagement: import.meta.env.VITE_FEATURE_DRIVER_MANAGEMENT === 'true',
};
{features.driverManagement && <DriversNavItem />}
```

### White-Label Theming

Branding is applied at runtime via CSS variables sourced from config, and Bootstrap SCSS variables at build time.

```scss
// custom-theme.scss
$primary: #{$env-primary-color};
@import 'bootstrap/scss/bootstrap';
```

## Security Considerations

1. **Password Storage**: Bcrypt via passlib, cost factor 12
2. **JWT Configuration**: 
   - Algorithm: HS256
   - Expiry: 24 hours (configurable via `JWT_EXPIRE_HOURS`)
   - Unique `JWT_SECRET_KEY` per client deployment
   - Stored in localStorage (httpOnly cookie recommended for production)
3. **Tenant Isolation**: Each client has a separate database file; no shared data
4. **Input Sanitization**: All inputs validated with Pydantic schemas
5. **SQL Injection Prevention**: SQLAlchemy ORM (parameterized queries)
6. **CORS**: Configured for allowed origins only
7. **HTTPS**: Mandatory in production (Let's Encrypt)
8. **Rate Limiting**: 100 requests per minute per IP (future enhancement)

## Future Mobile App Considerations

The architecture supports future mobile app integration:

1. **JWT Authentication**: Stateless, works across platforms
2. **RESTful API**: Standard HTTP methods, JSON responses
3. **Location API**: Endpoints ready for GPS tracking from mobile
4. **Driver Endpoints**: Ready for driver authentication and operations

### Mobile-Specific Endpoints (Future)

```
POST /api/mobile/auth/login      # Driver login
POST /api/mobile/location        # Update driver/vehicle location
GET  /api/mobile/assignments     # Get driver's assigned cargo
POST /api/mobile/operations      # Record load/unload from field
```

## Development Phases

### Phase 1: Foundation
- Project setup (FastAPI backend, Vite + React frontend)
- Database schema and Alembic migrations
- Configuration system (pydantic-settings, feature flags, .env)
- Authentication system (JWT + passlib)
- Basic UI layout (Bootstrap 5)

### Phase 2: Core Features
- Vehicle CRUD operations
- Cargo CRUD operations
- Driver CRUD operations
- Basic operations (load/unload)

### Phase 3: Dashboard & Map
- Dashboard with statistics
- Map integration with Leaflet
- Vehicle location tracking
- Recent operations display

### Phase 4: Polish
- Search and filtering
- Responsive design refinement
- Error handling improvements
- Form validation UX

## Dependencies

### Frontend (package.json)

```json
{
  "dependencies": {
    "react": "^18.2.0",
    "react-dom": "^18.2.0",
    "react-router-dom": "^6.20.0",
    "@tanstack/react-query": "^5.0.0",
    "axios": "^1.6.0",
    "leaflet": "^1.9.4",
    "react-leaflet": "^4.2.1",
    "date-fns": "^2.30.0",
    "bootstrap": "^5.3.0",
    "react-bootstrap": "^2.9.0"
  },
  "devDependencies": {
    "@types/react": "^18.2.0",
    "@types/leaflet": "^1.9.8",
    "typescript": "^5.3.0",
    "vite": "^5.0.0",
    "@vitejs/plugin-react": "^4.2.0"
  }
}
```

### Backend (requirements.txt)

```txt
# Web Framework
fastapi==0.109.0
uvicorn[standard]==0.27.0
python-multipart==0.0.6

# Database
sqlalchemy==2.0.25
alembic==1.13.1

# Authentication & Security
python-jose[cryptography]==3.3.0
passlib[bcrypt]==1.7.4
python-dotenv==1.0.0

# Validation
pydantic==2.5.3
pydantic-settings==2.1.0
email-validator==2.1.0

# CORS
fastapi-cors==0.0.6

# Development
pytest==7.4.4
pytest-asyncio==0.23.3
httpx==0.26.0  # For testing
```

## Correctness Properties

These invariants must always hold true regardless of the sequence of operations.

### Property 1: Unique License Plate
No two active vehicles share the same license plate.
**Validates: Requirements 2.5, 2.6**

### Property 2: Unique License Number
No two drivers share the same license number.
**Validates: Requirements 9.5**

### Property 3: Single Driver Assignment
A driver can be assigned to at most one vehicle at a time, and a vehicle to at most one driver.
**Validates: Requirements 9.3, 9.6**

### Property 4: Cargo-Vehicle Consistency
If cargo status is LOADED or IN_TRANSIT, it must have an associated `vehicle_id`. If status is PENDING, UNLOADED, or DELIVERED, `vehicle_id` must be null.
**Validates: Requirements 6.3, 7.3**

### Property 5: Loading Precondition
Cargo can only be loaded when its status is PENDING; loading rejects any other state.
**Validates: Requirements 6.2, 6.5**

### Property 6: Unloading Precondition
Cargo can only be unloaded when its status is LOADED or IN_TRANSIT.
**Validates: Requirements 7.2, 7.5**

### Property 7: Vehicle Status Derivation
A vehicle is IN_USE if and only if it has at least one cargo with status LOADED or IN_TRANSIT; otherwise it is AVAILABLE unless manually set to MAINTENANCE or INACTIVE.
**Validates: Requirements 11.3, 11.4**

### Property 8: Operation Immutability
Once created, an Operation record (the audit trail) is never modified or deleted.
**Validates: Requirements 8.1, 8.4**

### Property 9: Location Ordering
A vehicle's current position always reflects the Location record with the most recent timestamp.
**Validates: Requirements 4.1, 4.2**

> **Deferred (out of scope):** Tier-limit enforcement (MAX_VEHICLES/MAX_CARGO/MAX_DRIVERS) is a deployment-configuration concern deferred to a later update (see the Scope note under Configuration and Multi-Tenancy). It is intentionally not a validated correctness property in this build.

## Testing Strategy

### Unit Tests (Backend - pytest)
- Service layer business logic (load/unload state transitions, validation rules)
- Correctness property enforcement (e.g., loading rejects non-PENDING cargo)
- Pydantic schema validation (field formats, required fields, positive numbers)
- JWT token generation and verification

### Integration Tests (Backend - FastAPI TestClient)
- Full API endpoint flows using an in-memory/temp SQLite database
- Authentication middleware (401 for missing/invalid tokens)
- Feature flag enforcement (403 when feature disabled for tier)
- Tier limit enforcement (409/403 when limits exceeded)
- Database migrations apply cleanly

### Frontend Tests (Vitest + React Testing Library)
- Component rendering (forms, lists, cards)
- Form validation feedback and error display
- Map provider abstraction (mock IMapProvider)

### Manual / Exploratory Testing Checklist
- [ ] Vehicle CRUD across all statuses
- [ ] Cargo load/unload full lifecycle (PENDING → DELIVERED)
- [ ] Map marker display and updates
- [ ] Search and filtering on vehicles and cargo
- [ ] Responsive layout at desktop (1024px+) and tablet (768-1023px) widths
- [ ] Feature flags per tier (Basic/Standard/Premium)
- [ ] White-label branding (logo, colors) applied from .env

## Requirement Traceability

| Requirement | Design Components |
|-------------|-------------------|
| Req 1: User Authentication | AuthContext, LoginForm, auth routes, JWT middleware |
| Req 2: Vehicle Management | Vehicle model, vehicle routes, VehicleList, VehicleForm |
| Req 3: Vehicle Type Classification | VehicleType enum, VehicleForm type selector |
| Req 4: Vehicle Location Tracking | Location model, location routes, FleetMap, LocationHistory |
| Req 5: Cargo Management | Cargo model, cargo routes, CargoList, CargoForm |
| Req 6: Cargo Loading Operations | Operation model, load endpoint, LoadCargoModal |
| Req 7: Cargo Unloading Operations | Operation model, unload endpoint, UnloadCargoModal |
| Req 8: Cargo Operation History | operations routes, OperationList, CargoDetails |
| Req 9: Driver Management | Driver model, driver routes, DriverList, DriverForm |
| Req 10: Dashboard Overview | dashboard routes, Dashboard, StatsCard, FleetMap |
| Req 11: Vehicle Status Management | VehicleStatus enum, status endpoint, VehicleStatusBadge |
| Req 12: Search and Filtering | Query params on list endpoints, SearchBar, filters |
| Req 13: Data Validation | Pydantic schemas (backend), form validation (frontend) |
| Req 14: Responsive Web Design | Bootstrap 5 responsive grid, mobile-first approach |
