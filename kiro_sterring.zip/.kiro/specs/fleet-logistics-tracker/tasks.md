# Implementation Plan: Fleet and Logistics Management System

## Overview

This plan implements the Fleet and Logistics Management System as a single-user web
application with a Python + FastAPI backend (SQLAlchemy 2.0, Alembic, SQLite, JWT auth)
and a React 18 + TypeScript frontend (Bootstrap 5, TanStack Query, React Router v6, Vite,
Leaflet behind an `IMapProvider` abstraction).

The build proceeds bottom-up and test-driven: backend foundation (setup, config, models,
migrations, auth) first, then per-domain vertical slices (vehicles, locations, cargo,
operations, drivers, dashboard), then frontend foundation, then per-domain frontend, and
finally cross-cutting search/filtering and responsive polish. Each task builds on prior
work and ends by wiring components into the running application, with no orphaned code.

**Scope note:** Multi-tenancy, tier limits (`MAX_VEHICLES`/`MAX_CARGO`/`MAX_DRIVERS`),
feature-flag enforcement, and white-label theming are deferred deployment-configuration
concerns and are intentionally excluded from this plan (see the "Scope note (deferred)"
in design.md). Config modules are still read from environment variables (no hardcoding)
to keep the design forward-compatible.

## Tasks

- [ ] 1. Set up backend project structure and configuration
  - [ ] 1.1 Initialize backend project skeleton and dependencies
    - Create `backend/app` package layout (`api/routes`, `models`, `schemas`, `services`, `core`) per design
    - Add `requirements.txt` (FastAPI, uvicorn, SQLAlchemy 2.0, Alembic, python-jose, passlib[bcrypt], pydantic, pydantic-settings, email-validator, pytest, httpx)
    - Create empty `main.py` FastAPI app instance that starts and exposes `/docs`
    - _Requirements: 14.1_

  - [ ] 1.2 Implement configuration module
    - Create `core/config.py` using `pydantic-settings` reading from `.env` (JWT secret, JWT expiry, DB type/file, map provider)
    - Provide a `.env.example`; do not hardcode secrets or DB paths
    - _Requirements: 1.3_

  - [ ] 1.3 Implement database engine and session management
    - Create `core/database.py` with SQLAlchemy 2.0 engine, `SessionLocal`, and `Base`
    - Resolve `DATABASE_URL` from config (SQLite path)
    - Add `get_db` session dependency in `api/dependencies.py`
    - _Requirements: 2.1, 5.1_

- [ ] 2. Implement data models and migrations
  - [ ] 2.1 Implement SQLAlchemy ORM models and enums
    - Create model modules for User, Vehicle, Driver, Location, Cargo, Operation with enums (VehicleType, VehicleStatus, DriverStatus, CargoStatus, OperationType)
    - Define relationships and unique constraints (unique license_plate, unique license_no, unique driver vehicle_id)
    - _Requirements: 2.1, 2.5, 3.1, 4.4, 5.4, 9.5, 11.1_

  - [ ] 2.2 Configure Alembic and generate initial migration
    - Initialize Alembic, wire `env.py` to models `Base` metadata and config `DATABASE_URL`
    - Autogenerate and apply the initial schema migration
    - _Requirements: 2.1, 5.1_

  - [ ]* 2.3 Write integration test that migrations apply cleanly
    - Apply migrations against a temp SQLite DB and assert all tables/indexes exist
    - _Requirements: 2.1_

- [ ] 3. Implement authentication
  - [ ] 3.1 Implement security core (hashing + JWT)
    - Create `core/security.py` with passlib password hashing/verification and JWT create/decode using config
    - _Requirements: 1.1, 1.3_

  - [ ] 3.2 Implement auth schemas and service
    - Create `schemas/user.py` (login request, token/user response) and `services/auth_service.py` (authenticate, build token)
    - _Requirements: 1.1, 1.2_

  - [ ] 3.3 Implement auth routes and current-user dependency
    - Create `api/routes/auth.py` (`POST /api/auth/login`, `POST /api/auth/logout`, `GET /api/auth/me`)
    - Add `get_current_user` JWT dependency returning 401 on missing/invalid/expired token
    - Register the auth router in `main.py`
    - _Requirements: 1.1, 1.2, 1.4, 1.5_

  - [ ]* 3.4 Write unit tests for security core
    - Test password hash round-trip and JWT create/decode including expiry handling
    - _Requirements: 1.1, 1.3, 1.5_

  - [ ]* 3.5 Write integration tests for auth endpoints
    - Test valid login returns token, invalid credentials return error, `/me` requires valid token (401 otherwise)
    - _Requirements: 1.1, 1.2, 1.4, 1.5_

- [ ] 4. Checkpoint - backend foundation
  - Ensure all tests pass, ask the user if questions arise.

- [ ] 5. Implement vehicle domain (CRUD, type, status)
  - [ ] 5.1 Implement vehicle schemas and validation
    - Create `schemas/vehicle.py` with create/update/response and validation (license plate format 2-15 alphanumeric, type enum, make/model 2-50, year 1900..current+1)
    - _Requirements: 2.1, 3.1, 13.1, 13.2_

  - [ ] 5.2 Implement vehicle service
    - Create `services/vehicle_service.py`: create/list/get/update, deactivate (mark INACTIVE), unique-plate enforcement, status update with timestamp
    - _Requirements: 2.1, 2.2, 2.3, 2.4, 2.5, 2.6, 11.1, 11.2_

  - [ ] 5.3 Implement vehicle routes
    - Create `api/routes/vehicles.py` (GET list, GET by id, POST, PUT, PATCH status, DELETE) and register router; return 409 on duplicate plate
    - _Requirements: 2.1, 2.2, 2.3, 2.4, 2.6, 3.2, 11.2, 11.5_

  - [ ]* 5.4 Write property test for unique license plate
    - **Property 1: Unique License Plate**
    - **Validates: Requirements 2.5, 2.6**

  - [ ]* 5.5 Write unit/integration tests for vehicle CRUD and status
    - Test create/list/update/deactivate flows, status update timestamp, and validation errors (missing/invalid fields)
    - _Requirements: 2.1, 2.2, 2.3, 2.4, 11.2, 13.1, 13.2_

- [ ] 6. Implement vehicle location tracking
  - [ ] 6.1 Implement location schemas
    - Create location request/response schemas (latitude, longitude, timestamp)
    - _Requirements: 4.1, 4.2_

  - [ ] 6.2 Implement location service
    - Add location record, resolve current position as most-recent-timestamp record, return history filtered by time range
    - _Requirements: 4.1, 4.2, 4.4, 4.5_

  - [ ] 6.3 Implement location routes
    - Add `GET/POST /api/vehicles/{id}/locations` to the vehicles router with `from`/`to` query support
    - _Requirements: 4.1, 4.2, 4.5_

  - [ ]* 6.4 Write property test for location ordering
    - **Property 9: Location Ordering**
    - **Validates: Requirements 4.1, 4.2**

  - [ ]* 6.5 Write integration tests for location endpoints
    - Test adding locations, retrieving current position, and history within a time range
    - _Requirements: 4.2, 4.4, 4.5_

- [ ] 7. Implement cargo domain (CRUD)
  - [ ] 7.1 Implement cargo schemas and validation
    - Create `schemas/cargo.py` with create/update/response and validation (description 3-200, positive weight/dimensions, origin/destination 2-100)
    - _Requirements: 5.1, 13.1, 13.3_

  - [ ] 7.2 Implement cargo service
    - Create `services/cargo_service.py`: create/list/get (with operations)/update/delete, status tracking, assigned-vehicle exposure
    - _Requirements: 5.1, 5.2, 5.3, 5.4, 5.5_

  - [ ] 7.3 Implement cargo routes
    - Create `api/routes/cargo.py` (GET list, GET by id with operations, POST, PUT, DELETE) and register router
    - _Requirements: 5.1, 5.2, 5.3, 5.5_

  - [ ]* 7.4 Write unit tests for cargo validation
    - Test positive-number validation for weight/dimensions and required-field errors
    - _Requirements: 13.1, 13.3_

  - [ ]* 7.5 Write integration tests for cargo CRUD
    - Test create/list/get/update/delete and status defaulting to PENDING
    - _Requirements: 5.1, 5.2, 5.3, 5.4, 5.5_

- [ ] 8. Implement cargo operations (load/unload + history)
  - [ ] 8.1 Implement operation schemas
    - Create `schemas/operation.py` for load/unload requests and operation/history responses
    - _Requirements: 6.1, 7.1, 8.4_

  - [ ] 8.2 Implement loading logic in operation service
    - Create `services/operation_service.py` load flow: reject non-PENDING cargo, create LOADING operation, set cargo LOADED + vehicle_id, set vehicle IN_USE, record timestamp/location
    - _Requirements: 6.1, 6.2, 6.3, 6.4, 6.5, 11.3_

  - [ ] 8.3 Implement unloading logic in operation service
    - Add unload flow: reject cargo not LOADED/IN_TRANSIT, create UNLOADING operation, set cargo UNLOADED + clear vehicle_id, set vehicle AVAILABLE when no remaining active cargo, record timestamp/location
    - _Requirements: 7.1, 7.2, 7.3, 7.4, 7.5, 11.4_

  - [ ] 8.4 Implement operation routes and history
    - Create `api/routes/operations.py` (`POST /load`, `POST /unload`, `GET /operations` with date-range/vehicleId/cargoId filters, chronological order) and register router
    - _Requirements: 6.1, 7.1, 8.1, 8.2, 8.3, 8.4_

  - [ ]* 8.5 Write property test for loading precondition
    - **Property 5: Loading Precondition**
    - **Validates: Requirements 6.2, 6.5**

  - [ ]* 8.6 Write property test for unloading precondition
    - **Property 6: Unloading Precondition**
    - **Validates: Requirements 7.2, 7.5**

  - [ ]* 8.7 Write property test for cargo-vehicle consistency
    - **Property 4: Cargo-Vehicle Consistency**
    - **Validates: Requirements 6.3, 7.3**

  - [ ]* 8.8 Write property test for vehicle status derivation
    - **Property 7: Vehicle Status Derivation**
    - **Validates: Requirements 11.3, 11.4**

  - [ ]* 8.9 Write property test for operation immutability
    - **Property 8: Operation Immutability**
    - **Validates: Requirements 8.1, 8.4**

- [ ] 9. Implement driver domain (CRUD + assignment)
  - [ ] 9.1 Implement driver schemas and validation
    - Create `schemas/driver.py` with create/update/response and validation (name 2-100, phone format, optional email, unique license_no 5-20 alphanumeric)
    - _Requirements: 9.1, 13.1, 13.2_

  - [ ] 9.2 Implement driver service with assign/unassign
    - Create `services/driver_service.py`: create/list/get/update/deactivate, unique license enforcement, assign/unassign updating both driver and vehicle, detect already-assigned driver for confirmation
    - _Requirements: 9.1, 9.2, 9.3, 9.4, 9.5, 9.6_

  - [ ] 9.3 Implement driver routes
    - Create `api/routes/drivers.py` (GET list, GET by id, POST, PUT, assign, unassign, DELETE) and register router; signal confirmation-required case for already-assigned driver
    - _Requirements: 9.1, 9.2, 9.3, 9.4, 9.6_

  - [ ]* 9.4 Write property test for unique license number
    - **Property 2: Unique License Number**
    - **Validates: Requirements 9.5**

  - [ ]* 9.5 Write property test for single driver assignment
    - **Property 3: Single Driver Assignment**
    - **Validates: Requirements 9.3, 9.6**

  - [ ]* 9.6 Write integration tests for driver endpoints
    - Test CRUD, assign/unassign updating both records, and confirmation path for reassignment
    - _Requirements: 9.1, 9.2, 9.3, 9.4, 9.6_

- [ ] 10. Implement dashboard aggregation
  - [ ] 10.1 Implement dashboard service
    - Create dashboard aggregation: vehicle counts by status, cargo counts by status, active vehicles with latest location, recent operations
    - _Requirements: 10.1, 10.2, 10.3, 10.4_

  - [ ] 10.2 Implement dashboard routes
    - Create `api/routes/dashboard.py` (`/summary`, `/map`, `/recent-operations`) and register router
    - _Requirements: 10.1, 10.2, 10.3, 10.4, 10.5_

  - [ ]* 10.3 Write integration tests for dashboard endpoints
    - Test summary counts, map data payload, and recent operations ordering
    - _Requirements: 10.1, 10.2, 10.3, 10.4_

- [ ] 11. Wire backend application and search/filtering
  - [ ] 11.1 Wire application entrypoint and CORS
    - Ensure all routers registered in `main.py`, add CORS config and consistent API error handler matching the design's error format
    - _Requirements: 13.4_

  - [ ] 11.2 Implement search and filtering on list endpoints
    - Add query-param search/filter to vehicles (type/status/search across plate/make/model), cargo (status/search across description/origin/destination), drivers (status/search), and operations (date range/vehicle/cargo)
    - _Requirements: 3.3, 12.1, 12.2, 12.3, 12.4, 8.3_

  - [ ]* 11.3 Write integration tests for search and filtering
    - Test search matches, status filters, and clearing criteria returns all records
    - _Requirements: 12.1, 12.2, 12.3, 12.4_

- [ ] 12. Checkpoint - backend complete
  - Ensure all tests pass, ask the user if questions arise.

- [ ] 13. Set up frontend foundation
  - [ ] 13.1 Initialize Vite + React + TypeScript project with Bootstrap
    - Scaffold `frontend` with Vite React-TS, install React Router v6, TanStack Query, axios, Bootstrap 5, react-bootstrap, leaflet/react-leaflet, date-fns; import Bootstrap styles
    - _Requirements: 14.1, 14.3_

  - [ ] 13.2 Define shared TypeScript types
    - Create `types/` for vehicle, cargo, driver, operation, user matching API contracts
    - _Requirements: 2.1, 5.1, 9.1_

  - [ ] 13.3 Implement API client with error handling
    - Create `services/api.ts` (axios instance, JWT header injection, response error normalization to `ApiError`)
    - _Requirements: 1.3, 13.4_

  - [ ] 13.4 Implement auth context, service, and protected routing
    - Create `authService`, `AuthContext`/`useAuth`, token persistence, `ProtectedRoute`, and `LoginPage`/`LoginForm` handling login errors and logout; redirect to login on 401/expiry
    - _Requirements: 1.1, 1.2, 1.3, 1.4, 1.5_

  - [ ] 13.5 Implement app layout and routing shell
    - Create `AppLayout`, `Sidebar`, `Header`, `PageContainer`, configure React Router routes and TanStack Query provider in `App.tsx`/`main.tsx`
    - _Requirements: 14.1, 14.2, 14.3_

  - [ ]* 13.6 Write component test for LoginForm
    - Test validation feedback and error display on invalid credentials
    - _Requirements: 1.2, 13.1_

- [ ] 14. Implement map provider abstraction
  - [ ] 14.1 Define IMapProvider interface and Leaflet implementation
    - Create `IMapProvider` abstraction, a Leaflet-backed implementation, and `FleetMap` rendering vehicle markers (implement Leaflet only)
    - _Requirements: 4.3, 10.3_

  - [ ]* 14.2 Write component test for FleetMap with mock IMapProvider
    - Render FleetMap against a mock provider and assert markers for provided vehicles
    - _Requirements: 4.3, 10.3_

- [ ] 15. Implement vehicles frontend
  - [ ] 15.1 Implement vehicle service and hooks
    - Create `vehicleService` and `useVehicles` (list/get/create/update/status/delete/locations) via TanStack Query
    - _Requirements: 2.1, 2.2, 2.3, 2.4, 11.2_

  - [ ] 15.2 Implement vehicle list, card, and status badge
    - Create `VehicleList`, `VehicleCard`, `VehicleStatusBadge`, `VehiclesPage` showing type and status
    - _Requirements: 2.2, 3.2, 11.5_

  - [ ] 15.3 Implement vehicle form with validation
    - Create `VehicleForm` with client-side validation preserving entered data on error; wire create/edit
    - _Requirements: 2.1, 2.3, 2.6, 3.1, 13.1, 13.2, 13.4_

  - [ ] 15.4 Implement vehicle details and location history
    - Create `VehicleDetailPage`/`VehicleDetails` showing latest location and `LocationHistory`
    - _Requirements: 4.2, 4.5, 8.2_

  - [ ]* 15.5 Write component tests for vehicle form and list
    - Test validation feedback, type selection, and list rendering
    - _Requirements: 2.2, 13.1, 13.2_

- [ ] 16. Implement cargo frontend
  - [ ] 16.1 Implement cargo service and hooks
    - Create `cargoService` and `useCargo` (list/get/create/update/delete)
    - _Requirements: 5.1, 5.2, 5.3_

  - [ ] 16.2 Implement cargo list, card, and status badge
    - Create `CargoList`, `CargoCard`, `CargoStatusBadge`, `CargoPage`
    - _Requirements: 5.2, 5.4_

  - [ ] 16.3 Implement cargo form with validation
    - Create `CargoForm` validating positive weight/dimensions and required fields, preserving data on error
    - _Requirements: 5.1, 5.3, 13.1, 13.3, 13.4_

  - [ ] 16.4 Implement cargo details with operation history
    - Create `CargoDetailPage`/`CargoDetails` showing full details, status, assigned vehicle, and associated operations
    - _Requirements: 5.5, 8.1_

  - [ ]* 16.5 Write component tests for cargo form and details
    - Test positive-number validation and operation history rendering
    - _Requirements: 13.3, 8.1_

- [ ] 17. Implement operations frontend
  - [ ] 17.1 Implement operation service and hooks
    - Create `operationService` and `useOperations` (list with filters, load, unload)
    - _Requirements: 6.1, 7.1, 8.3_

  - [ ] 17.2 Implement load and unload modals
    - Create `LoadCargoModal` and `UnloadCargoModal` handling success and rejection errors (already loaded / not loaded)
    - _Requirements: 6.1, 6.5, 7.1, 7.5_

  - [ ] 17.3 Implement operation list with filters
    - Create `OperationList`, `OperationCard`, `OperationFilters`, `OperationsPage` with date-range/vehicle/cargo filtering in chronological order
    - _Requirements: 8.2, 8.3, 8.4_

  - [ ]* 17.4 Write component tests for operation modals
    - Test successful submission and error display for invalid state transitions
    - _Requirements: 6.5, 7.5_

- [ ] 18. Implement drivers frontend
  - [ ] 18.1 Implement driver service and hooks
    - Create `driverService` and `useDrivers` (list/get/create/update/assign/unassign/delete)
    - _Requirements: 9.1, 9.2, 9.3, 9.4_

  - [ ] 18.2 Implement driver list, card, and form
    - Create `DriverList`, `DriverCard`, `DriverForm`, `DriverDetails`, `DriversPage` with assignment status and validation
    - _Requirements: 9.1, 9.2, 13.1, 13.2_

  - [ ] 18.3 Implement assign driver modal with confirmation
    - Create `AssignDriverModal` prompting confirmation when the driver is already assigned to another vehicle
    - _Requirements: 9.3, 9.4, 9.6_

  - [ ]* 18.4 Write component tests for driver assignment
    - Test reassignment confirmation prompt and unique-license validation feedback
    - _Requirements: 9.5, 9.6_

- [ ] 19. Implement dashboard frontend
  - [ ] 19.1 Implement dashboard service and hooks
    - Create `dashboardService` and `useDashboard` (summary, map, recent operations)
    - _Requirements: 10.1, 10.2, 10.4_

  - [ ] 19.2 Implement dashboard page
    - Create `DashboardPage`/`Dashboard` with `StatsCard` counts, `FleetMap`, `RecentOperations`, and manual refresh; redirect here after login
    - _Requirements: 1.1, 10.1, 10.2, 10.3, 10.4, 10.5_

  - [ ]* 19.3 Write component tests for dashboard
    - Test stats rendering and manual refresh triggering data reload
    - _Requirements: 10.1, 10.2, 10.5_

- [ ] 20. Implement search/filtering UI and responsive polish
  - [ ] 20.1 Wire search and filter UI across list pages
    - Create shared `SearchBar` and status filter controls; wire to vehicles, cargo, drivers, and operations lists; support clearing criteria
    - _Requirements: 3.3, 12.1, 12.2, 12.3, 12.4_

  - [ ] 20.2 Refine responsive layout and touch targets
    - Apply Bootstrap responsive grid for desktop (1024px+) and tablet (768-1023px); ensure 44x44px minimum touch targets and layout reflow
    - _Requirements: 14.1, 14.2, 14.3, 14.4_

  - [ ]* 20.3 Write component tests for search and filtering
    - Test search matching, status filtering, and clearing restores full lists
    - _Requirements: 12.1, 12.3, 12.4_

- [ ] 21. Final checkpoint - full stack integration
  - Ensure all tests pass, ask the user if questions arise.

## Notes

- Tasks marked with `*` are optional test sub-tasks and can be skipped for a faster MVP.
- Each task references specific requirements for traceability; property test tasks also reference the design's Correctness Properties.
- All 9 active correctness properties are covered: P1 (5.4), P2 (9.4), P3 (9.5), P4 (8.7), P5 (8.5), P6 (8.6), P7 (8.8), P8 (8.9), P9 (6.4).
- Backend tests use pytest + FastAPI TestClient; frontend tests use Vitest + React Testing Library.
- Deferred concerns (multi-tenancy, tier limits, feature flags, white-label theming) are intentionally excluded per the design scope note.
- Development servers (uvicorn, Vite) should be run manually by the user, not by the coding agent.

## Task Dependency Graph

```json
{
  "waves": [
    { "id": 0, "tasks": ["1.1"] },
    { "id": 1, "tasks": ["1.2", "1.3"] },
    { "id": 2, "tasks": ["2.1"] },
    { "id": 3, "tasks": ["2.2", "3.1"] },
    { "id": 4, "tasks": ["2.3", "3.2", "5.1", "6.1", "7.1", "8.1", "9.1"] },
    { "id": 5, "tasks": ["3.3", "5.2", "6.2", "7.2", "9.2", "10.1"] },
    { "id": 6, "tasks": ["3.4", "3.5", "5.3", "6.3", "7.3", "8.2", "9.3", "10.2"] },
    { "id": 7, "tasks": ["5.4", "5.5", "6.4", "6.5", "7.4", "7.5", "8.3", "9.4", "9.5", "9.6", "10.3"] },
    { "id": 8, "tasks": ["8.4", "11.1"] },
    { "id": 9, "tasks": ["8.5", "8.6", "8.7", "8.8", "8.9", "11.2"] },
    { "id": 10, "tasks": ["11.3", "13.1"] },
    { "id": 11, "tasks": ["13.2", "13.3"] },
    { "id": 12, "tasks": ["13.4", "13.5", "14.1"] },
    { "id": 13, "tasks": ["13.6", "14.2", "15.1", "16.1", "17.1", "18.1", "19.1"] },
    { "id": 14, "tasks": ["15.2", "15.3", "16.2", "16.3", "17.2", "18.2", "19.2"] },
    { "id": 15, "tasks": ["15.4", "16.4", "17.3", "18.3", "20.1"] },
    { "id": 16, "tasks": ["15.5", "16.5", "17.4", "18.4", "19.3", "20.2"] },
    { "id": 17, "tasks": ["20.3"] }
  ]
}
```
