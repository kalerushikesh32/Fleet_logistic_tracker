---
inclusion: auto
---

# Coding Style

## Principles

KISS, DRY, YAGNI — simple, no duplication, no speculative abstractions.

Follow SOLID principles and design patterns. Should take LLD & HLD design decisions.

## Structure

- Small functions (<50 lines), small files (<400 lines typical, 800 max)
- Early returns over deep nesting (max 4 levels)
- Meaningful names — code should be self-documenting
- Named constants over magic numbers
- Comments explain "why", not "what"
- No dead code. Delete it, don't comment it out.
- Error handling is not optional. Handle errors at every boundary.
