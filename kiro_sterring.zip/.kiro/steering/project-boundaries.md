---
inclusion: auto
---

# Project Boundaries — CRITICAL, ALWAYS FOLLOW

This project (`project_1` / fleet-logistics-tracker) is **fully independent**.

## Hard rules

1. **Never read, modify, reference, or touch any files/directories outside this
   project's own root folder.** This includes sibling folders, parent directories,
   other office/work projects, or anything not created as part of this project.
2. **Never use, read, reference, or act on any API keys, credentials, secrets,
   or config found outside this project.** Do not scan the filesystem for
   credentials to "reuse." Do not assume shared config with other projects.
3. This project's own secrets (e.g. `backend/.env`) are for this project only —
   never copy them elsewhere, never copy values in from elsewhere.
4. If a task seems to require something outside this project's root (e.g. an
   external API key, a shared library, another repo), **stop and ask the user
   explicitly** rather than searching for or assuming it.

## Why

The user's machine contains other, unrelated office/work directories and
credentials. Touching them — even accidentally via a broad search or glob —
risks leaking or corrupting unrelated work and could cause real problems for
the user professionally. This boundary is non-negotiable.

## Scope reminder

Everything relevant to this project lives under this project's root:
`backend/`, `frontend/`, `docs/`, `.kiro/`, and the root-level config files
(`.gitignore`, `docker-compose.yml`, `Dockerfile`, `README.md`, etc.). There is
no dependency on anything outside this tree.
